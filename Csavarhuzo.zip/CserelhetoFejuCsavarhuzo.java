import java.util.Locale;

public class CserelhetoFejuCsavarhuzo extends Csavarhuzo{

    private int fejMeret;
    private boolean egyhornyuFej = true;
    private boolean phillipsFej = true;
    private boolean imbuszFej = true;


    public CserelhetoFejuCsavarhuzo(int meret,int fejMeret, Csavarfej csavarfej) {
        super(meret, csavarfej);
        this.fejMeret = fejMeret;

    }
    public void fejElhagy(String melyik){
        if(melyik.equals("egyhornyu")){
            this.egyhornyuFej = false;
        }
        else if(melyik.equals("phillips")){
            this.phillipsFej = false;
        }
        else if(melyik.equals("imbusz")){
            this.imbuszFej = false;
        }
    }

    public boolean fejCsere(String melyikre){
        if(String.valueOf(getCsavarfej()).equals(melyikre.toUpperCase())){
            return false;
        }
        else if(melyikre.equals("egyhornyu")){
            if(!this.egyhornyuFej){
                return false;
            }
            else {
                this.csavarfej = Csavarfej.EGYHORNYU ;
                return true;
            }
        }
        else if(melyikre.equals("phillips")){
            if(!this.phillipsFej){
                return false;
            }
            else {
                this.csavarfej = Csavarfej.PHILLIPS ;
                return true;
            }
        }
        else if(melyikre.equals("imbusz")){
            if(!this.imbuszFej){
                return false;
            }
            else {
                this.csavarfej = Csavarfej.IMBUSZ ;
                return true;
            }
        }
        else return false;
    }

    public int getMeret(){
        return super.getMeret()-this.fejMeret;
    }
}
