public class Csavarhuzo {
    private int meret;
    protected Csavarfej csavarfej;

    public Csavarhuzo(int meret, Csavarfej fej){
        this.meret = meret;
        this.csavarfej = fej;
    }

    public void setMeret(int meret){
        this.meret = meret;
    }


    public int getMeret(){
        return this.meret;
    }
    public Csavarfej getCsavarfej(){
        return this.csavarfej;
    }
    public String toString(){
        if(getCsavarfej() == Csavarfej.EGYHORNYU){
            return "hagyomanyos feju csavarhuzo";
        }
        else if(getCsavarfej() == Csavarfej.PHILLIPS){
            return  "csillagfeju csavarhuzo";
        }
        else if(getCsavarfej() == Csavarfej.IMBUSZ){
            return  "imbuszfeju csavarhuzo";
        }
        else return "";
    }
}
