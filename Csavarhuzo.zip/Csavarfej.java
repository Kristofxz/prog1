public enum Csavarfej {
    EGYHORNYU,
    PHILLIPS,
    IMBUSZ

    }
